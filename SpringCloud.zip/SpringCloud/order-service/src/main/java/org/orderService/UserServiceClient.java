package org.orderService;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "user-service")  // 确保这个 name 与 user-service 的注册名一致
public interface UserServiceClient {
    @GetMapping("/users")
    String getUsers();
}

