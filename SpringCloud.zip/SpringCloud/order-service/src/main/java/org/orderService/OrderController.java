package org.orderService;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {

    private static final Logger log = LogManager.getLogger(OrderController.class);
    private final UserServiceClient userServiceClient;

    public OrderController(UserServiceClient userServiceClient) {
        this.userServiceClient = userServiceClient;
    }

    @GetMapping("/orders")
    public String getOrders() {
        log.info("Order Service called");
        return "Order Service calling " + userServiceClient.getUsers();
    }
}
