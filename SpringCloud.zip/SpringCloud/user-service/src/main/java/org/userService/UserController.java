package org.userService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.userService.entity.UserEntity;
import org.userService.mapper.UserMapper;

import java.util.UUID;

@RestController
public class UserController {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private UserMapper userMapper;

    @GetMapping("/users")
    public String getUsers() {
        long timestamp = System.currentTimeMillis(); // 当前时间戳
        long randomPart = (long) (Math.random() * 10000); // 随机数，避免碰撞
        long uniqueId = timestamp * 10000 + randomPart; // 将时间戳和随机数拼接成唯一的 ID

        System.out.println("Generated unique ID: " + uniqueId);
        jdbcTemplate.execute("INSERT INTO account (id, phone) VALUES (" + uniqueId + ", '1234567890')");

//        UserEntity userEntity = new UserEntity();
//        userEntity.setPhone("1234567890");
//        userMapper.insert(userEntity);

        return "User Service: Hello from 8085" + System.currentTimeMillis();
    }
}
